let lixosAtivos = []; // Array para armazenar os lixos que aparecem na tela
let composteiraNivel = 0; // Nível da composteira, de 0 a 100
let alimentosColhidos = 0;
let pontuacao = 0;

const LIXEIRAS = { // Posições e cores das lixeiras de descarte
  organico: { x: 100, y: 400, cor: [139, 69, 19] }, // Marrom para orgânico
  plastico: { x: 250, y: 400, cor: [255, 0, 0] },   // Vermelho para plástico
  papel: { x: 400, y: 400, cor: [0, 0, 255] },     // Azul para papel
  vidro: { x: 550, y: 400, cor: [0, 200, 0] },     // Verde para vidro
  metal: { x: 700, y: 400, cor: [200, 200, 0] }     // Amarelo para metal
};

let hortaAtiva = false; // Estado da horta
let alimentosNaHorta = []; // Alimentos prontos para colheita na horta

let itemArrastando = null; // Lixo que está sendo arrastado pelo mouse
let offsetX, offsetY; // Deslocamento do mouse para arrastar

function setup() {
  createCanvas(800, 600);
  // Gerar lixo novo a cada 2.5 segundos
  setInterval(gerarNovoLixo, 2500);
  // Gerar alimentos na horta a cada 3 segundos, se a horta estiver ativa
  setInterval(gerarAlimentoNaHorta, 3000);
}

function draw() {
  background(135, 206, 235); // Céu azul

  drawCenario(); // Desenha a cidade e o fundo

  drawLixeiras(); // Desenha as lixeiras de descarte

  drawComposteira(); // Desenha a composteira e seu nível

  if (hortaAtiva) {
    drawHorta(); // Desenha a área da horta
    for (let i = alimentosNaHorta.length - 1; i >= 0; i--) {
      drawAlimentoHorta(alimentosNaHorta[i]); // Desenha os alimentos na horta
    }
  }

  // Desenha os lixos que precisam ser descartados
  for (let i = lixosAtivos.length - 1; i >= 0; i--) {
    let lixo = lixosAtivos[i];
    if (lixo !== itemArrastando) { // Não desenha o lixo se ele estiver sendo arrastado
      drawLixo(lixo);
    }
  }

  // Desenha o item que está sendo arrastado por último (para ficar por cima)
  if (itemArrastando) {
    drawLixo(itemArrastando);
  }

  drawPlacar(); // Desenha a pontuação e contadores
  exibirMensagem(); // Mostra mensagens de feedback
}

function mousePressed() {
  // Verifica se clicou em algum lixo para começar a arrastar
  for (let i = lixosAtivos.length - 1; i >= 0; i--) {
    let lixo = lixosAtivos[i];
    // Verifica se o clique está dentro da área do lixo
    if (dist(mouseX, mouseY, lixo.x, lixo.y) < 20) { 
      itemArrastando = lixo;
      // Calcula o deslocamento para o lixo não "pular" para o centro do mouse
      offsetX = mouseX - lixo.x;
      offsetY = mouseY - lixo.y;
      break; 
    }
  }

  // Verifica se clicou em alimento na horta para colher
  if (hortaAtiva) {
    for (let i = alimentosNaHorta.length - 1; i >= 0; i--) {
      let alimento = alimentosNaHorta[i];
      if (dist(mouseX, mouseY, alimento.x, alimento.y) < 15) { // Área de clique do alimento
        alimentosNaHorta.splice(i, 1); // Remove o alimento colhido
        alimentosColhidos++;
        pontuacao += 10;
        mostrarFeedback("Alimento colhido! Delícia!", 1500, [0, 150, 0]);
        break;
      }
    }
  }
}

function mouseDragged() {
  if (itemArrastando) {
    itemArrastando.x = mouseX - offsetX;
    itemArrastando.y = mouseY - offsetY;
  }
}

function mouseReleased() {
  if (itemArrastando) {
    let descartadoCorretamente = false;

    // Tenta descartar na composteira (somente orgânico)
    if (itemArrastando.tipo === 'organico' && 
        dist(itemArrastando.x, itemArrastando.y, LIXEIRAS.organico.x + 25, LIXEIRAS.organico.y + 25) < 50) {
      composteiraNivel = min(100, composteiraNivel + 10); // Aumenta o nível da composteira
      pontuacao += 20;
      mostrarFeedback("Orgânico na composteira! Boa!", 1500, [0, 100, 0]);
      descartadoCorretamente = true;
      if (composteiraNivel >= 50 && !hortaAtiva) { // Horta nasce com 50% de composteira
        hortaAtiva = true;
        mostrarFeedback("Sua horta urbana nasceu! Hora de colher!", 3000, [0, 180, 0]);
      }
    } 
    
    // Tenta descartar nas lixeiras de reciclagem
    else {
      for (let tipoLixo in LIXEIRAS) {
        // Ignora a lixeira de orgânico aqui
        if (tipoLixo !== 'organico' && 
            dist(itemArrastando.x, itemArrastando.y, LIXEIRAS[tipoLixo].x + 25, LIXEIRAS[tipoLixo].y + 25) < 50) {
          if (itemArrastando.tipo === tipoLixo) { // Acertou o tipo de lixo
            pontuacao += 15;
            mostrarFeedback(itemArrastando.tipo.charAt(0).toUpperCase() + itemArrastando.tipo.slice(1) + " reciclado!", 1500, [0, 0, 150]);
            descartadoCorretamente = true;
          } else { // Errou o tipo de lixo
            pontuacao -= 5;
            mostrarFeedback("Ops! Lixo no lugar errado!", 1500, [200, 0, 0]);
          }
          break; // Já encontrou uma lixeira, para de verificar
        }
      }
    }

    // Se o lixo não foi descartado corretamente em nenhuma lixeira
    if (!descartadoCorretamente) {
      pontuacao -= 5; // Perde pontos se soltar em lugar errado ou em lugar nenhum
      mostrarFeedback("Descarte correto é importante! Tente de novo.", 1500, [200, 50, 0]);
    }

    // Remove o item que foi arrastado, independentemente do descarte
    lixosAtivos = lixosAtivos.filter(item => item !== itemArrastando);
    itemArrastando = null; // Reseta o item arrastando
  }
}

// --- Funções de Desenho ---
function drawCenario() {
  // Gramado no chão
  fill(120, 200, 100);
  rect(0, height / 2, width, height / 2);

  // Casas (exemplo simples)
  fill(255, 250, 205); // Amarelo claro
  rect(50, 200, 100, 150);
  rect(300, 150, 80, 100);
  fill(150, 100, 50); // Telhado
  triangle(50, 200, 150, 200, 100, 150);
  triangle(300, 150, 380, 150, 340, 100);
}

function drawLixeiras() {
  for (let tipo in LIXEIRAS) {
    fill(LIXEIRAS[tipo].cor[0], LIXEIRAS[tipo].cor[1], LIXEIRAS[tipo].cor[2]);
    rect(LIXEIRAS[tipo].x, LIXEIRAS[tipo].y, 50, 50);
    fill(255);
    textSize(10);
    textAlign(CENTER, TOP);
    text(tipo.toUpperCase(), LIXEIRAS[tipo].x + 25, LIXEIRAS[tipo].y - 15);
    textAlign(LEFT, BASELINE); // Volta ao padrão
  }
}

function drawComposteira() {
  let comp = LIXEIRAS.organico;
  fill(comp.cor[0], comp.cor[1], comp.cor[2]);
  rect(comp.x, comp.y, 50, 50); // Base da composteira

  // Preenchimento da composteira
  let fillHeight = map(composteiraNivel, 0, 100, 0, 48);
  fill(80, 50, 0); // Cor de terra/composto
  rect(comp.x + 1, comp.y + 49 - fillHeight, 48, fillHeight);
  
  fill(255);
  textSize(10);
  textAlign(CENTER, TOP);
  text("COMPOSTEIRA", comp.x + 25, comp.y - 15);
  textAlign(LEFT, BASELINE);
}

function drawHorta() {
  // Posição da horta (ao lado da composteira)
  let hortaX = LIXEIRAS.organico.x + 70;
  let hortaY = LIXEIRAS.organico.y - 20;

  fill(120, 200, 100); // Base verde da horta
  rect(hortaX, hortaY, 150, 70);
  fill(80, 50, 0); // Terra da horta
  rect(hortaX + 5, hortaY + 5, 140, 60);

  fill(0);
  textSize(14);
  textAlign(LEFT, BASELINE);
  text("Nossa Horta Urbana!", hortaX, hortaY - 5);
}

function drawAlimentoHorta(alimento) {
  push();
  translate(alimento.x, alimento.y);
  fill(alimento.cor[0], alimento.cor[1], alimento.cor[2]);
  ellipse(0, 0, 20); // Ícone simples de alimento (círculo)
  // Poderíamos adicionar formas mais complexas ou imagens aqui
  pop();
}

function drawLixo(lixo) {
  push();
  translate(lixo.x, lixo.y);
  // Desenho simplificado de cada tipo de lixo
  if (lixo.tipo === 'organico') {
    fill(100, 80, 0);
    ellipse(0, 0, 25, 20); // Forma de casca
  } else if (lixo.tipo === 'plastico') {
    fill(255, 100, 100);
    rect(-10, -15, 20, 30, 5); // Forma de garrafa
  } else if (lixo.tipo === 'papel') {
    fill(200, 200, 255);
    rect(-15, -10, 30, 20); // Forma de papel amassado
  } else if (lixo.tipo === 'vidro') {
    fill(150, 255, 150);
    ellipse(0, 0, 20); // Forma de vidro/garrafa redonda
  } else if (lixo.tipo === 'metal') {
    fill(180, 180, 180);
    rect(-12, -12, 24, 24); // Forma de lata quadrada
  }
  pop();
}

function drawPlacar() {
  fill(0);
  textSize(18);
  text("Pontuação: " + pontuacao, 10, 25);
  text("Alimentos Colhidos: " + alimentosColhidos, 10, 50);
  text("Composteira: " + composteiraNivel + "%", 10, 75);
}

// --- Funções de Lógica ---
function gerarNovoLixo() {
  // Tipos de lixo disponíveis para aparecer
  let tipos = ['organico', 'plastico', 'papel', 'vidro', 'metal'];
  let tipoAleatorio = random(tipos);

  // Posição inicial do lixo (saindo de uma casa)
  let xCasa = random([100, 340]); // Posições das casas no cenário
  let yCasa = random([200, 150]);

  lixosAtivos.push({ 
    x: xCasa + random(-10, 10), 
    y: yCasa + random(80, 120), // Sai da base da casa
    tipo: tipoAleatorio 
  });
}

function gerarAlimentoNaHorta() {
  if (hortaAtiva && alimentosNaHorta.length < 5 && random() < 0.8) { // Gera se a horta tá ativa e há espaço
    let alimentosPossiveis = ['alface', 'tomate', 'cenoura'];
    let tipoAlimento = random(alimentosPossiveis);
    let corAlimento;

    if (tipoAlimento === 'alface') corAlimento = [0, 180, 0];
    else if (tipoAlimento === 'tomate') corAlimento = [255, 60, 60];
    else corAlimento = [255, 165, 0]; // Cenoura

    let hortaX = LIXEIRAS.organico.x + 70;
    let hortaY = LIXEIRAS.organico.y - 20;

    alimentosNaHorta.push({ 
      x: hortaX + random(20, 130), 
      y: hortaY + random(20, 60), 
      tipo: tipoAlimento, 
      cor: corAlimento 
    });
  }
}

// Para exibir mensagens de feedback na tela
let mensagemFeedback = "";
let tempoMensagemTermina = 0;
let corMensagem = [0, 0, 0];

function mostrarFeedback(msg, duracao, cor) {
  mensagemFeedback = msg;
  tempoMensagemTermina = millis() + duracao;
  corMensagem = cor;
}

function exibirMensagem() {
  if (mensagemFeedback !== "" && millis() < tempoMensagemTermina) {
    fill(corMensagem[0], corMensagem[1], corMensagem[2]);
    textSize(22);
    textAlign(CENTER, CENTER);
    text(mensagemFeedback, width / 2, height - 50);
    textAlign(LEFT, BASELINE); // Volta ao padrão
  }
}